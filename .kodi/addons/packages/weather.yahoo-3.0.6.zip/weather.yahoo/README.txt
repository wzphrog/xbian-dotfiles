Info for Skinners

Available properties:
- Current.Location
- Current.Condition
- Current.Temperature
- Current.Wind
- Current.WindDirection
- Current.WindChill
- Current.Humidity
- Current.Visibility
- Current.Pressure
- Current.FeelsLike
- Current.DewPoint
- Current.ConditionIcon
- Current.FanartCode
- Today.Sunrise
- Today.Sunset

Day[0-3]
- Day%i.Title
- Day%i.HighTemp
- Day%i.LowTemp
- Day%i.Outlook
- Day%i.OutlookIcon
- Day%i.FanartCode
